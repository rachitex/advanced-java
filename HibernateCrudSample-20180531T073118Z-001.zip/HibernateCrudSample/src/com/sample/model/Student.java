package com.sample.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name = "STUDENT")
public class Student {
    @Id
    @Column(name="STUDENT_ID")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long id;
    
    @Column(name="STUDENT_NAME")
    private String name;
    
    @Column(name="ROLL_NUMBER")
    private String rollNumber;
    
    @Column(name="COURSE")
    private String courseName;
    
    public long getId() {
        return id;
    }
 
    public void setId(long id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
 
    public String getCourseName() {
        return courseName;
    }
 
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
 
    public String getRollNumber() {
        return rollNumber;
    }
 
    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }
    
    @Override
    public String toString() {
        return "Student Details = Id: " + this.id + ", Name: " + this.name + ", Roll No.: " + this.rollNumber + ", Course: " + this.courseName;
    }

 
}