/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.main;

import com.sample.db.operations.DBOperationsManager;
import com.sample.model.Student;
import java.util.List;

public class CrudOperations {

    private static DBOperationsManager<Student> dbManager = new DBOperationsManager<Student>();
    public static void main(String[] args) {
        
        //CRUD
        //createStudent();
        /*listAllStudent();
        updateStudent();
        deleteStudent();
        deleteAllStudent();*/
        
        //CRITERIA
        listStudents();
        System.exit(0);
    } 
        
    private static void createStudent(){
        System.out.println("***************************CREATE START************************");
        for(int i=0; i<5; i++){
            Student student = new Student();
            student.setName("Name"+i);
            student.setRollNumber("10"+i);
            student.setCourseName("MCA"+i);
            dbManager.save(student);
        }
        System.out.println("Student Created Successfully");
        System.out.println("***************************CREATE END************************\n\n");
    }
    
    private static void updateStudent(){
        System.out.println("***************************UPDATE START************************");
        int updateId = 3;
        Object studentObject = dbManager.findById(updateId, Student.class);
	Student student = null;
        if(studentObject != null){
            student = (Student)studentObject;
        }
        System.out.println("BEFORE UPDATE");
	if(student != null) {
            System.out.println(student.toString());
            student.setName("Chris");
            student.setRollNumber("101");
            student.setCourseName("MCA");
            dbManager.update(student);
            System.out.println("AFTER UPDATE");
            student = (Student)dbManager.findById(updateId, Student.class);
            System.out.println(student.toString());
        }else{
            System.out.println("No Record Found");
        }
        System.out.println("***************************UPDATE END************************\n\n");
    }
    
    private static void listAllStudent(){
        System.out.println("\n\n***************************LIST ALL START************************");
        List <Student> students = dbManager.list(Student.class);
         if(students != null && !students.isEmpty()){
            for(Student student :  students){
                System.out.println(student.toString());
            }
        }else{
            System.out.println("No Records Found");   
        }
        System.out.println("***************************LIST ALL END************************\n\n");
    }
    
    private static void deleteStudent(){
        System.out.println("***************************DELETE STUDENT START************************");
        Student student = new Student();
        student.setId(3);
        dbManager.delete(student);
        listAllStudent();
        System.out.println("***************************DELETE STUDENT END************************\n\n");
    }
    
    private static void deleteAllStudent(){
        System.out.println("***************************DELETE ALL START************************");
        dbManager.deleteAll(Student.class);
        listAllStudent();
        System.out.println("***************************DELETE ALL END************************\n\n");
    }
    
    
    private static void listStudents(){
        List<Student> students = dbManager.getStudentsList();
        if(students != null && !students.isEmpty()){
            for(Student student : students){
                System.out.println(student.getName());
                System.out.println(student.getRollNumber());
                System.out.println(student.getCourseName());
            }
        }
    }
}
