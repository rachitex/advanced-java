/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sample.db.operations;

import com.sample.model.Student;
import com.sample.util.HibernateUtil;
import org.hibernate.classic.Session;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

/**
 *
 * @author Avadhesh Sharma
 * @param <T>
 */
public class DBOperationsManager<T> {
            
    private Session session;
    private Transaction transaction;
    
    private void openSession(){
       session = HibernateUtil.getSessionFactory().openSession();
    }
        
    private void beginTransaction(){
       transaction = session.beginTransaction();
    }
    
    public void save(T clazz){
        try{
            openSession();
            beginTransaction();
            session.save(clazz);
            transaction.commit();
            closeSession();
        }catch(Exception ex){
            transaction.rollback();
            ex.printStackTrace();
        }
    }
    
    public void update(T clazz){
        try{
            openSession();
            beginTransaction();
            session.merge(clazz);
            transaction.commit();
            closeSession();
        }catch(Exception ex){
            transaction.rollback();
            ex.printStackTrace();
        }
    }
    
    public List list(Class model){
        List<T> objects = null;
        try{
           openSession();
           beginTransaction();
           objects = session.createCriteria(model).list();
           closeSession();
        }catch(Exception ex){
            ex.printStackTrace();
        }
         return objects;
    }
    
    public void delete(T clazz){
        try{
            openSession();
            beginTransaction();
            session.delete(clazz);
            transaction.commit();
            closeSession();
        }catch(Exception ex){
            transaction.rollback();
            ex.printStackTrace();
        }
    }
    
    public void deleteAll(Class clazz){
        try{
            openSession();
            beginTransaction();
            session.createQuery("DELETE "+clazz.getSimpleName()).executeUpdate();
            transaction.commit();
            closeSession();
        }catch(Exception ex){
            transaction.rollback();
            ex.printStackTrace();
        }
    }
    
    public Object findById(long id, Class model){
        openSession();
        beginTransaction();
        Object entity = session.get(model, id);
        closeSession();
        return entity;
    }
    
    private void closeSession(){
        session.close();
    }
    
    
    public List<Student> getStudentsList(){
        List<Student> studentsList = null;
        openSession();
        Criteria criteria = session.createCriteria(Student.class);
        
        //Projection
        ProjectionList p1 = Projections.projectionList();
        p1.add(Projections.property("name"), "name");
        p1.add(Projections.property("rollNumber"), "rollNumber"); 
        criteria.setProjection(p1);
        criteria.setResultTransformer(Transformers.aliasToBean(Student.class));
        
        //Restrictions
        criteria.add(Restrictions.eq("courseName", "MCA1"));
        studentsList = criteria.list();
        closeSession();
        return studentsList;
    }
    
    
}
